<?php
/**
 * Created by PhpStorm.
 * User: huqi1
 * Date: 2018/3/9
 * Time: 15:28
 */

include_once "function.php";
echo gamePage("mainTitle","gameName",4,3,1,"infoText","user",5);
//echo noCertification("reasonTitle","reasonTxt");
//finishGame(1);
?>