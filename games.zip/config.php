<?php
/**
 * Created by PhpStorm.
 * User: huqi1
 * Date: 2018/1/13
 * Time: 19:46
 * This is used to config the web.
 */
$config=array(
    "SQL_URL"=>"localhost",
    "SQL_User"=>"root",
    "SQL_Password"=>"",
    "SQL_Port"=>"3306",
    "SQL_Database"=>"test",
);
